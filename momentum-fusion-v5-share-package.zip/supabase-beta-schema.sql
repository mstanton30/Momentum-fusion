-- Run in a dedicated Supabase project after reviewing security and consent policies.
create table if not exists public.beta_members (user_id uuid primary key references auth.users(id) on delete cascade, active boolean not null default false);
alter table public.beta_members enable row level security;
-- No client policies: membership is read only by trusted server-side service role.
create table if not exists public.ai_usage (user_id uuid not null references auth.users(id) on delete cascade, usage_date date not null, count integer not null default 0, primary key(user_id,usage_date));
alter table public.ai_usage enable row level security;
create or replace function public.consume_ai_quota(p_user_id uuid,p_daily_limit integer) returns boolean
language plpgsql security definer set search_path = public as $$
declare n integer;
begin
  if p_daily_limit < 1 or p_daily_limit > 100 then return false; end if;
  insert into public.ai_usage(user_id,usage_date,count) values(p_user_id,current_date,1)
  on conflict(user_id,usage_date) do update set count=ai_usage.count+1
  where ai_usage.count < p_daily_limit
  returning count into n;
  return n is not null;
end $$;
revoke all on function public.consume_ai_quota(uuid,integer) from public, anon, authenticated;
grant execute on function public.consume_ai_quota(uuid,integer) to service_role;

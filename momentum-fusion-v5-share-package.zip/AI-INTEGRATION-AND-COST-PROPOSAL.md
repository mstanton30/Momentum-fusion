# Momentum Fusion — AI Integration and Cost Proposal

**Decision document for the two developers | November 2026**

## Executive summary
Momentum Fusion v5 is a shareable, standalone Get Ripped–based prototype with **simulated AI Preview** features. It does **not** send prompts to OpenAI, Claude or any external AI provider, and no API key or paid AI account is needed to explore the experience. The existing Get Ripped and Momentum applications are unchanged.

**Proposed decision:** first validate the user experience together, then implement real AI with an authenticated backend and measured costs. Do not enable unrestricted public AI endpoints.

## User-facing AI capabilities

| Feature | Preview now | Real integration later |
|---|---|---|
| Meal analysis | Demonstrates editable macro fields using keyword-based sample values | AI extracts foods, portions, protein, carbs, fat, fiber and calories, and returns uncertainty |
| Activity analysis | Classifies common activity descriptions using simple examples | AI extracts activity, duration and intensity; a validated MET-based calculation estimates energy use |
| Coaching | Demonstration message based on logged-entry counts | AI summarizes real weekly trends and recommends 1–2 practical actions |
| Saved favorites | Save and reuse meals and workouts | Same data structure; AI-generated estimates require review before saving |
| Workout substitutions | Choose keep, move, skip or add activity | AI may suggest substitutions, but user approves plan changes |
| RENPHO | Manual entry and CSV import | iOS HealthKit bridge reads permitted Apple Health data |

**Important:** The prototype's AI Preview is a simulation, not an actual model call. Sample meal estimates are not reliable enough for health decisions. The prototype stores data in the browser only, not in a synchronized account.

## Recommended architecture

1. **Frontend:** GitHub Pages for the static app. Keep the repository independent from the original Get Ripped repository. Public Pages means public source code; never commit secrets.
2. **Authentication and database:** Supabase Auth with invite-only signup; Postgres tables for users, meals, activities, workout templates, weigh-ins and feedback. Enforce row-level security and user ownership. Require email verification; admins manage invitations and can view aggregate usage, not private health logs by default.
3. **AI gateway:** Supabase Edge Functions or a similar authenticated server-side function. Validate session tokens, apply per-user quotas and request-size limits, call the chosen model, validate structured JSON responses, log usage and costs, and return sanitized results. Store API credentials only in server-side secrets.
4. **Model abstraction:** A provider interface supporting OpenAI and potentially Claude later, with consistent request and response schemas. Do not switch providers without evaluating cost, accuracy, privacy and terms.
5. **Data privacy:** Consent and clear disclosures for sensitive fitness and body-composition data, export/delete controls, retention limits, restricted admin access and backup/recovery processes. No API keys or health records in public source files.
6. **Apple Health / RENPHO:** A website cannot directly access HealthKit. A later native iOS companion or authorized bridge would import permitted weight, body-fat and workout samples. Handle duplicate Apple Watch and WHOOP workouts and preserve source provenance.

## Suggested implementation sequence

**Stage A — Two-person proof of concept:** Make Nutrition and Workout screens call one authenticated backend endpoint. Start with meal analysis and activity parsing. Add editable result review, error states, and daily request limits. Do not turn on AI for anonymous visitors.

**Stage B — Two-person coaching:** Use aggregated weekly data, not entire raw histories when unnecessary. Add opt-in coaching summaries and explain the data used. Test outputs against known examples and manually verify estimates.

**Stage C — Invite-only beta (15–20 users):** Implement invitation codes or email invitations, individual accounts, data synchronization, audit/usage logs, cost dashboard, feedback and support process. Test account isolation and data deletion before invitations.

**Stage D — Devices:** Build a HealthKit-enabled iOS bridge for Apple Watch and RENPHO-via-Apple-Health, then evaluate WHOOP OAuth and API access. Only promise measurements that each integration actually exposes.

## Cost scenarios (planning estimates, not vendor quotes)

AI providers generally charge per input and output token. Actual charges vary by model, prompt size, response length, retries, and provider pricing. The scenarios below assume **text-only** analysis and average blended per-call costs; these are hypothetical planning rates, not verified current price quotes.

| Scenario | Users | Requests/user/day | Avg cost/request | AI cost/30 days |
|---|---:|---:|---:|---:|
| Light two-person testing | 2 | 5 | $0.001 | $0.30 |
| Active two-person testing | 2 | 10 | $0.005 | $3.00 |
| Moderate beta | 20 | 5 | $0.003 | $9.00 |
| Heavy beta / richer coaching | 20 | 10 | $0.010 | $60.00 |

For the two-person prototype, set an **initial $10/month AI planning cap**, with alerts and enforced server-side request quotas. A cap in the provider dashboard alone may not be a hard stop; enforce a separate application quota. For the 20-user beta, budget **$20–$100/month in AI allowance** until measured traffic is available, plus hosting, database, email, logging, storage, and potential iOS development expenses. Costs may be higher with larger models, images, long coaching contexts or unexpectedly heavy usage.

**Example cost formula:** monthly AI spend = active users × average requests/user/day × 30 × measured cost/request. Track input/output tokens and provider billable usage per request.

## Product quality and safety requirements

- Make all estimates editable and label confidence/uncertainty. Never treat food-description estimates as laboratory measurements.
- Use validated activity energy formulas and user-approved duration/intensity; do not ask a language model to invent a calorie number without constraints.
- Avoid double counting overlapping Apple Watch and WHOOP workouts.
- Keep macro guidance age-appropriate and avoid restrictive recommendations for minors without appropriate safeguards.
- Present smart-scale body-fat values as trends affected by hydration, not precise muscle/fat measurements.
- Add privacy notice, consent, secure transport, user data deletion and backup before real-user beta use.
- Run usability tests on iPhone and desktop; test malformed AI responses, no-network states, account isolation, rate limits and excessive spending.

## Go / no-go decision after testing

Proceed to live AI only if both developers agree that: (1) the quick-log flow is faster than manual entry, (2) estimates are sufficiently useful after editing, (3) saved favorites reduce repeated effort, (4) coaching is actionable rather than generic, (5) projected costs are acceptable, and (6) user data and keys can be protected.

**Current state:** v5 is a shareable local prototype, not a deployed website, not a live AI app, and not yet a multiuser beta system. It should not be used to store sensitive health information in a shared browser.

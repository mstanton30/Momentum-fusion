// Secure AI gateway. Intentionally refuses public/unauthenticated requests.
const json=(data,status=200)=>new Response(JSON.stringify(data),{status,headers:{'content-type':'application/json','cache-control':'no-store'}});
export default async (request)=>{
 if(request.method!=='POST')return json({error:'Method not allowed'},405);
 const env=k=>Netlify.env.get(k);
 const url=env('SUPABASE_URL'),anon=env('SUPABASE_ANON_KEY'),service=env('SUPABASE_SERVICE_ROLE_KEY'),key=env('OPENAI_API_KEY');
 if(!url||!anon||!service||!key)return json({error:'AI is not configured for the private beta yet.'},503);
 const token=(request.headers.get('authorization')||'').match(/^Bearer (.+)$/)?.[1];
 if(!token)return json({error:'Please sign in to use AI.'},401);
 try{
  const u=await fetch(`${url}/auth/v1/user`,{headers:{apikey:anon,authorization:`Bearer ${token}`}});
  if(!u.ok)return json({error:'Invalid login.'},401);
  const user=await u.json();if(!user.id)return json({error:'Invalid login.'},401);
  // Explicit invite-only allowlist. Database RLS should protect user data independently.
  const permitted=await fetch(`${url}/rest/v1/beta_members?user_id=eq.${encodeURIComponent(user.id)}&active=eq.true&select=user_id&limit=1`,{headers:{apikey:service,authorization:`Bearer ${service}`}});
  if(!permitted.ok)return json({error:'Beta membership verification unavailable.'},503);
  const members=await permitted.json();if(!members.length)return json({error:'This account is not invited to the beta.'},403);
  const input=await request.json();const kind=input.kind;
  if(!['meal','activity','coach'].includes(kind))return json({error:'Invalid analysis type.'},400);
  const description=String(input.description||input.summary||'').slice(0,1200);
  if(description.length<4)return json({error:'Add a description.'},400);
  // Atomic per-user daily quota, enforced in the database before every AI call.
  const quota=await fetch(`${url}/rest/v1/rpc/consume_ai_quota`,{method:'POST',headers:{apikey:service,authorization:`Bearer ${service}`,'content-type':'application/json'},body:JSON.stringify({p_user_id:user.id,p_daily_limit:20})});
  if(!quota.ok)return json({error:'AI usage controls are not configured yet.'},503);
  if(await quota.json()!==true)return json({error:'Daily AI limit reached.'},429);
  const schema=kind==='meal'?{type:'object',properties:{p:{type:'number'},c:{type:'number'},f:{type:'number'},fiber:{type:'number'},calories:{type:'number'},note:{type:'string'}},required:['p','c','f','fiber','calories','note'],additionalProperties:false}:kind==='activity'?{type:'object',properties:{minutes:{type:'number'},intensity:{type:'string',enum:['light','moderate','vigorous']},note:{type:'string'}},required:['minutes','intensity','note'],additionalProperties:false}:{type:'object',properties:{advice:{type:'string'}},required:['advice'],additionalProperties:false};
  const prompt=kind==='meal'?'Estimate approximate grams of protein, carbs, fat, fiber and calories from the meal description. Mention uncertainty and do not invent precise portions.':kind==='activity'?'Classify exercise intensity and duration from the description. Do not claim precise calorie expenditure.':'Provide one brief, non-medical actionable coaching suggestion based only on provided summary.';
  const response=await fetch('https://api.openai.com/v1/responses',{method:'POST',headers:{authorization:`Bearer ${key}`,'content-type':'application/json'},body:JSON.stringify({model:env('OPENAI_MODEL')||'gpt-4o-mini',instructions:prompt,input:description,text:{format:{type:'json_schema',name:'estimate',schema,strict:true}},max_output_tokens:350})});
  if(!response.ok)return json({error:'AI service temporarily unavailable.'},502);
  const body=await response.json();const output=(body.output||[]).flatMap(o=>o.content||[]).filter(x=>x.type==='output_text').map(x=>x.text).join('');
  return json(JSON.parse(output));
 }catch{return json({error:'AI request failed. Please try again.'},500)}
};
export const config={rateLimit:{action:'rate_limit',aggregateBy:'ip',windowSize:60,windowLimit:10}};
